package com.lab6.problem3;
public class DomException extends Exception {

    public DomException() {
        super();
    }

    public DomException(String s) {
        super(s);
    }

}

